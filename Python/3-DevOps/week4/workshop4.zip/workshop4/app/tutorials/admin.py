from django.contrib import admin
from .models import Tutorial

# Register your models here.
admin.site.register(Tutorial)